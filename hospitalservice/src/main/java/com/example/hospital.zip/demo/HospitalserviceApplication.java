package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitalserviceApplication.class, args);
	}

}
